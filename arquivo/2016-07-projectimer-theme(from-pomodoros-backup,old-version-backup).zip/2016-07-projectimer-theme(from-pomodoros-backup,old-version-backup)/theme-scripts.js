//Francisco Matelli
jQuery().ready(function($) {
	/*$.each( "#header-content div span", function(index, value) {
		$(this).hide();
	});*/
	
	$(window).resize(function() {
		adjust();
	});
	adjust();
	
	function adjust() {
		//first adjust viewport (all between footer and height) height
		var headerFooterHeight = $("#header").height()+$("#footer").height();
		$("#viewport").css("height", (window.innerHeight-headerFooterHeight)+"px");
		$("#viewport").css("width", (window.innerWidth)+"px");
		//second adjust height in horizontal bars inside viewport 
		$(".viewport-horizontal-bar").css("height", (window.innerHeight-headerFooterHeight)+"px");
		//$("#contenter_activities").css("height", (window.innerHeight-headerFooterHeight)+"px");
		//$("#contenter_timer_tasks").css("height", (window.innerHeight-headerFooterHeight)+"px");
		/*
		if(window.innerWidth>920) {
			//Large (BIG DESKTOP and TV)
			$(".show-in-big-screen").hide();
			$("#contenter_timer_tasks").css("width", window.innerWidth);
		} else if(window.innerWidth<920 || window.innerWidth>600) {
			//Medium Screens (NOTEBOOK)
			$("#contenter_timer_tasks").css("width", (window.innerWidth)-$("#contenter_activities").width());
		} else if() {
			//Small screens (TABLET)
		} else if() {
			//Tiny screen (PHONE)
		} else if () {
			//Extra tiny (WATCH)
		}*/
	}
	
	if($("#timer_button").length) {
		//IN FOCUS PAGE, there is a scroll on panel on rigth, making 2 vertical scrollers but confusing
		$("#viewport").css("overflow", "hidden");//TODO: teoricamente nao precisaria disso, testar
	}
	
	/*
	if($("#timer-new-window").length) {
		$("#timer-new-window").click(function()  {
			window.open(url,'liveMatches','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=720,height=800');
		});
	}*/	

	/**/
	$( ".contem-icone " ).mouseenter(function() {
		if(!$(this).find( ".icone-legenda" ).is(":animated")) {
			//console.log("enter");
			//var contemIcone = $ (this);
			$(this).css("background-color", "rgba(0, 0, 0, 0.5)");
			$(this).find( ".icone-legenda" ).animate({width:'show'},150);

			/*.slideDown(400, function() {
				console.log("slideDown complete");
				/*$(this).mouseout(function() {
					console.log("mouseout1");
					//contemIcone.find( ".icone-legenda" ).slideUp(400);
					//$( ".icone-legenda" ).slideUp(400);
				});//*
				console.log(contemIcone.html());
				
			});*/
		} else {
			$(this).css("background-color", "rgba(0, 0, 0, 0.5)");
			$(this).find( ".icone-legenda" ).show();
			//$(this).find( ".icone-legenda" ).animate({width:'show'},0);;
		}
		/*$(this).*/
	});

	$( ".contem-icone " ).mouseleave(function() {
		//console.log("mouseout2");
		//contemIcone.find( ".icone-legenda" ).slideUp(400);
		//$( this ).find( ".icone-legenda" ).hide(400);
		$(this).css("background-color", "transparent");
		$( this ).find( ".icone-legenda" ).animate({width:'hide'},250);
		//.animate({width:'toggle'},350);
	});
	/*$( "#header " ).mouseleave(function() {
		$( ".icone-legenda" ).hide();
	});*/
	$( ".icone-legenda" ).hide();
	/*$( ".contem-icone" ).mouseout(function() {

		$(this).find( ".icone-legenda" ).slideUp(400);

		//$( ".icone-legenda" ).slideUp(400);
	});*/
	$( "#login_login" ).click(function() {
		$( "#loginlogbox" ).toggle("slow");
	});
	$( "#settings_button" ).click(function() {
		$( "#projectimer_settingsbox" ).toggle("slow");
	});
	$( ".button_close" ).click(function() {
		$( "#projectimer_settingsbox" ).hide("slow");
	});
	if($("#loading-message").length) {
		i = 0;
		loading_animated = setInterval(function() {
		    i = ++i % 4;
		    $("#loading-message").find("p").html("loading"+Array(i+1).join("."));
		}, 200);
	}
	
});
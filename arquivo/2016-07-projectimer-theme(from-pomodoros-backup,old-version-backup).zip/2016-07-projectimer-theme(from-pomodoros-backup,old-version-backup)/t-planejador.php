<?php
/*Template Name: Pomo - Planejador (goals)*/
?>
<?php get_header() ?>

<div class="content_nosidebar">
     
</div><!-- #content -->
	
<?php get_footer() ?>
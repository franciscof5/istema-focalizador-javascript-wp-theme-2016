<?php
/* Template Name: Pomo - Focar */
?>
<?php get_header() ?>

<?php 

//get_sidebar(); 
//wp_enqueue_script('jquery'); queued before settings every time
wp_enqueue_script('projectimer-js');
//wp_enqueue_script('soundmanager');
//wp_enqueue_style('clockcss');

//projectimer_check_activity();
?>

<?php //locate_template( array( 's-pomodoros.php' ), true ); ?>
<!--div id="loading-message"><p>.</p><p class="dots">..</p></div-->
<?php /* 
<!--BOOTSTRAP TAB HTMLdiv class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
	<ul id="myTab" class="nav nav-tabs" role="tablist">
	  <li role="presentation" class="active"><a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">Countdown</a></li>
	  <li class="" role="presentation"><a aria-expanded="false" href="#profile" role="tab" id="profile-tab" data-toggle="tab" aria-controls="profile">Free laps</a></li>
	</ul>
	<div id="myTabContent" class="tab-content">
	  <div role="tabpanel" class="tab-pane fade active in" id="home" aria-labelledby="home-tab">
		<div class="pomodoro-relogio">
			<?php do_action("projectimer_show_clock_simplist"); ?>
		</div>
		<p>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache cliche tempor, williamsburg carles vegan helvetica. Reprehenderit butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi, qui irure terry richardson ex squid. Aliquip placeat salvia cillum iphone. Seitan aliquip quis cardigan american apparel, butcher voluptate nisi qui.</p>
	  </div>
	  <div role="tabpanel" class="tab-pane fade" id="profile" aria-labelledby="profile-tab">
		<p>Food truck fixie locavore, accusamus mcsweeney's marfa nulla single-origin coffee squid. Exercitation +1 labore velit, blog sartorial PBR leggings next level wes anderson artisan four loko farm-to-table craft beer twee. Qui photo booth letterpress, commodo enim craft beer mlkshk aliquip jean shorts ullamco ad vinyl cillum PBR. Homo nostrud organic, assumenda labore aesthetic magna delectus mollit. Keytar helvetica VHS salvia yr, vero magna velit sapiente labore stumptown. Vegan fanny pack odio cillum wes anderson 8-bit, sustainable jean shorts beard ut DIY ethical culpa terry richardson biodiesel. Art party scenester stumptown, tumblr butcher vero sint qui sapiente accusamus tattooed echo park.</p>
	  </div>
	</div>
  </div>
  SECOND TRY BUT NO LUCK
<div class="container-fluid">
	<div class="row">
		<div class="col-xs-6 col-md-5 col-md-offset-1 col-lg-3">
			recent activities
		</div>
		
		<div class="col-xs-6 col-md-4 col-md-offset-1 col-lg-3">
			<div class="row">
				<div class="col-xs-12"></div>
			</div>
			<div class="row">
				<div class="col-xs-12"></div>
			</div>
		</div>
		
		<div class="col-xs-12 col-lg-3">
			ainda nao sei o que por aqui
		</div>
	</div>
</div-->*/ ?>

<div class="row">

	<div id="contenter_projects" class="viewport-horizontal-bar col-xs-6 col-md-4">
		<div><?php do_action("projectimer_show_projects"); ?></div>
	</div>

	<div id="contenter_timer_tasks" class="viewport-horizontal-bar col-xs-6 col-md-4">
		<div id="contenter_timer" style="width: 80px;margin: 0 auto;"><?php do_action("projectimer_show_timer_simplist"); ?></div>
		<div id="contenter_tasks" style="padding: 0 20%;"><?php do_action("projectimer_show_task_form"); ?></div>
	</div>

	<div id="contenter_activities" class="viewport-horizontal-bar col-md-4">
		<!--a>Filtro: somente eu, amigos, todos</a-->
		<?php do_action("projectimer_show_recent_activities"); ?>
	</div>
</div>
<?php get_footer() ?>

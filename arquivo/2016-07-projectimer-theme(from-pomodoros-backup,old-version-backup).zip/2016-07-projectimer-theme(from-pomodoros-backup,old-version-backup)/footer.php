		
		<!--div class="push"></div-->
		<!--/div> <!-- #wrapper #2D2D2D-->
		
		</div> <!--viewport-->

		<?php do_action( 'bp_after_container' ) ?>

		<?php do_action( 'bp_before_footer' ) ?>

		<div id="footer">
			<div id="footer-opacity">
			<?php do_action( 'bp_footer' ) ?>
			<p id="footer-signature">
				<a href="http://www.f5sites.com">F5 Sites</a>
				 | 
				<a href="<?php bloginfo('url'); ?>/coworkers/francisco/">Francisco Matelli</a>
				</p>
			<!--p style="float:right;"><a href="<?php bloginfo('url'); ?>/projeto/pomodoros-2"><?php _e("Follow pomodoros project", "sistema-pomodoros"); ?></a></p-->
			<p style="float:right;"><?php do_action('icl_language_selector'); ?></p>
			</div>
		</div>
		
		<?php 
		if($_GET["template"]=="mini") 
		echo '<style>#header,#footer,#activities-bar,#contenter_tasks,#ambiance-notification,#div_status,#timer-new-window{height:0;display:none}body{overflow:hidden;background:#333;}#contenter_timer_tasks{width:100%;}</style>';
		?>
		<?php do_action( 'bp_after_footer' ) ?>

		<?php wp_footer(); ?>

	</body>

</html>
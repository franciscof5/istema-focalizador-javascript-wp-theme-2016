<?php get_header(); ?>

	<div id="content" class="content_nosidebar">
		<div class="padder">
a
		</div><!-- .padder -->
	</div><!-- #content -->

<?php get_footer(); ?>
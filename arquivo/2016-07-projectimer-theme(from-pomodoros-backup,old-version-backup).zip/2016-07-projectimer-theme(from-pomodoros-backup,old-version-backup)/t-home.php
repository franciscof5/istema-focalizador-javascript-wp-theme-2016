<?php
/*Template Name: Pomo - Home*/

/*Language files are loaded on header*/
?>

<?php 
if (is_user_logged_in()) {
	wp_redirect( home_url()."/focus" ); exit;
}
 ?>

<?php get_header('buddypress') ?>
<div class="row viewport-horizontal-bar">
	<div id="contenter_blog" class=" col-md-4 col-lg-4">
		<div style="padding:20px 0 20px;">
			<div class="circulo" id="">
				<h3>Pomodoros.com.br</h3>
				<p>Rede de produtividade, para pessoas e equipes compartilharem seus projeto e estudos com colegas.</p>
			</div>
			<div class="circulo" id="">
				<h3>Como funciona</h3>
				<p>Escreva a tarefa que precisa fazer e inicie o cronômetro, você deve focar na sua tarefa sem distrações.</p>
			</div>
			<div class="circulo" id="">
				<h3>Técnica dos Pomod.</h3>
				<p>São 25 minutos focando na tarefa e 5 minutos de descanso, formando um ciclo. Após 4 ciclos tem um intervalo de 20 minutos.</p>
			</div>
			<div class="circulo" id="">
				<h3>Origem</h3>
				<p>Criada pelo italiano Francesco Cerello, na década de 80, para estudar para provas. Usava um relógio em forma de tomate, para tempo de pizza.</p>
			</div>
			<div class="circulo" id="">
				<h3>Benefícios</h3>
				<p>Ajuda a cumprir prazos | Mais foco e produtividade | Maior controle sobre demandas | Diminui ansiedade</p>
			</div>
			<div class="circulo" id="">
				<h3>Funcionalidade</h3>
				<p>Calendário de produtividade | Sorteio de prêmios | Seu tempo nas nuvens</p>
			</div>
			<div class="circulo" id="">
				<h3>Produção em rede</h3>
				<p>Estamos vivendo no tempo da co-criação, compartilhando idéias e pensamentos. Convide seus colegas para estudar ou trabalhar em rede.</p>
			</div>
			<div class="circulo" id="">
				<h3>Brasil</h3>
				<p>Tecnologia nacional, desenvolvida por empresa brasileira.</p>
				<img src="<?php bloginfo('stylesheet_directory'); ?>/images/brasil.jpg" height="40px" alt="Bandeira do Brasil" />
			</div>
		</div><!-- #content -->
	</div>

	<div id="contenter_register" class="-horizontal-bar col-xs-6 col-md-4 col-lg-4">
		Register
	</div>

	<div id="contenter_login" class="-horizontal-bar col-xs-6 col-md-4 col-lg-4">
		<h4>Register</h4>
		<a href="/register">Go to registration page</a>
		<h4>Login</h4>
		<?php wp_login_form(); ?>
		<?php do_action( 'bp_after_sidebar_login_form' ); ?>
		
		<?php 
		//<h4>Login com o Facebook</h4>
		//if ( function_exists(jfb_output_facebook_btn)){jfb_output_facebook_btn();} 
		?>
	</div>
</div>
		
<?php get_footer('buddypress') ?>
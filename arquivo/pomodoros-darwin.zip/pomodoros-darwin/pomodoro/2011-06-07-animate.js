// JavaScript Document
var seconds_to_set = 1500;
//
var m1;
var m2;
var m3;
var m4;
//initial time
//var h_current = -1;
var m1_current = 2;
var m2_current = 5;
var s1_current = 0;
var s2_current= 0;
/*f5*/
var pomodoro_actual = 1;
//flip_pomodoro("pomoindi2");

//var interval_clock;


function ativar(time) {
	//pegar o valor dividir por 60 e por string setar o m1 e m2, o resto sao os segundos
	//set_to(seconds_to_set);
	//Inicio
	secondsRemaing=seconds_to_set;
	convertSeconds(secondsRemaing)
	interval_clock = setInterval('retroClock()', 10);
	
	/*
	m1 = 2;
	m2 = 4;
	s1 = 5;
	s2 = 9;
	*/
	//seconds=10;
	//minutesRemaing=25;
	//set_to_25();
	//
	//flip_pomodoro(1);
}
function convertSeconds(secs) {
	/*someValueString = '' + secs;
	someValueParts = someValueString.split('');
	frontPart = someValueParts[1];
	*/
	minutes=secs/60;
	if(minutes>10) {
		someValueString = '' + minutes;
		someValueParts = someValueString.split('');
		m1 = parseFloat(someValueParts[0]);
		m2 = parseFloat(someValueParts[1]);
	} else {
		m1 = parseFloat(0);
		m2 = parseFloat(minutes);
	}
	//seconds%=secs/60;
	if(secs%60!=0) {
		seconds=secs%60;
		otherValueString = '' + seconds;
		otherValueParts = otherValueString.split('');
		s1 = parseFloat(otherValueParts[0]);
		s2 = parseFloat(otherValueParts[1]);
	} else {
		s1=0;
		s2=0;
	}
	//m1 = ;
	//alert(m1+""+m2+":"+s1+""+s2);
	
	
	/*
	m1 = 2;
	m2 = 4;
	s1 = 5;
	s2 = 9;
	*/
}
function cancelar() {
	window.clearInterval(interval_clock);
	interval_clock="";
	//flip_pomodoro("pomoindi2");
}

function set_to_25() {
	m1=2;m2=5;s1=0;s2=0;
	flip('minutesUpRight', 'minutesDownRight', 5, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Right/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Right/');
	flip('minutesUpLeft', 'minutesDownLeft', 2, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Left/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Left/');
	flip('secondsUpRight', 'secondsDownRight', 0, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Right/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Right/');
	flip('secondsUpLeft', 'secondsDownLeft', 0, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Left/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Left/');
}
function set_to_0() {
	flip('minutesUpRight', 'minutesDownRight', 0, 'Double/Up/Right/', 'Double/Down/Right/');
	flip('minutesUpLeft', 'minutesDownLeft', 0, 'Double/Up/Left/', 'Double/Down/Left/');
	flip('secondsUpRight', 'secondsDownRight', 0, 'Double/Up/Right/', 'Double/Down/Right/');
	flip('secondsUpLeft', 'secondsDownLeft', 0, 'Double/Up/Left/', 'Double/Down/Left/');
}



//logo abaixo eh declarada var minutesRemaing=25;	

function flip (upperId, lowerId, changeNumber, pathUpper, pathLower){
	var upperBackId = upperId+"Back";
	$(upperId).src = $(upperBackId).src;
	$(upperId).setStyle("height", "64px");
	$(upperId).setStyle("visibility", "visible");
	$(upperBackId).src = pathUpper+parseInt(changeNumber)+".png";
	
	$(lowerId).src = pathLower+parseInt(changeNumber)+".png";
	$(lowerId).setStyle("height", "0px");
	$(lowerId).setStyle("visibility", "visible");
	
	var flipUpper = new Fx.Tween(upperId, {duration: 200, transition: Fx.Transitions.Sine.easeInOut});
	flipUpper.addEvents({
		'complete': function(){
			var flipLower = new Fx.Tween(lowerId, {duration: 200, transition: Fx.Transitions.Sine.easeInOut});
				flipLower.addEvents({
					'complete': function(){	
						lowerBackId = lowerId+"Back";
						$(lowerBackId).src = $(lowerId).src;
						$(lowerId).setStyle("visibility", "hidden");
						$(upperId).setStyle("visibility", "hidden");
					}				});					
				flipLower.start('height', 64);
				
		}
						});
	flipUpper.start('height', 0);
	
	
}//flip
function flip_pomodoro (pomo) {
	//alert(pomo);
	//var flipPomo = new Fx.Tween($(pomo), {duration: 200, transition: Fx.Transitions.Sine.easeInOut});
	//flipPomo.start();
	var pomo = $(pomo);
	
	pomo.set('morph', {
		duration: 2000
	});
	
	pomo.morph({
		'background-position': '-30px',
		//'border': '2px solid #F00',
		'background-color': '#FFF'
	});
}
	
function is_int(value){ 
	if((parseFloat(value) == parseInt(value)) && !isNaN(value)){
	    return true;
	} else { 
	    return false;
	}
}
function retroClock(){
	secondsRemaing--;
	convertSeconds(secondsRemaing);
	if(secondsRemaing<0) {
		cancelar();
	}
	/*if(is_int(secondsRemaing/60)) {
		//1minutos
		m2--;
		s1=5;
		s2=9;
		if(m2<0){
			//
			m2=9;
			m1--;
		}
	}
	s2--;
	if(s2<0) {
		//10segundos
		s1--;
		s2=9;
		if(s1<0) {
			s1=9;
		}
	}
	if(secondsRemaing==1) {
		cancelar();
		flip_pomodoro("pomoindi"+pomodoro_actual);
		pomodoro_actual++;
	} 
	/*else {
		//seconds changing
		if(is_int(secondsRemaing/60)) {
			//s2 changing
			trace("2s");
		} else {
			//s1 changing
			trace("1s");
		}
			
	}*/
	/*CODIGO ANTIGO
	if(((minutesRemaing*60)-secondsRemaing)<60) {
			//Vai aqui se for baixar os segundos
			//alert();
			if(((minutesRemaing*60)-secondsRemaing)<seconds)
			s2=seconds-((minutesRemaing*60)-secondsRemaing);
			else {
				s1--;
				seconds+=10;
			}
		} else {
			minutesRemaing--;
			m2--;
			seconds=10;
			s1=5;
		}
		//Vai aqui se for baixar os minutos
		if(secondsRemaing==1) {
			cancelar();
			flip_pomodoro("pomoindi"+pomodoro_actual);
			pomodoro_actual++;
		} else if(secondsRemaing==10*60) {
			m1=0;
			m2=9;
		} else if(secondsRemaing==20*60) {
			m1=1;
			m2=9;
		}
	
	//}*/
	
	if( m2 != m2_current){
		flip('minutesUpRight', 'minutesDownRight', m2, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Right/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Right/');
		m2_current = m2;
		
		flip('minutesUpLeft', 'minutesDownLeft', m1, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Left/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Left/');
		m1_current = m1;
	}
	
	 if (s2 != s2_current){
		flip('secondsUpRight', 'secondsDownRight', s2, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Right/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Right/');
		s2_current = s2;
		
		flip('secondsUpLeft', 'secondsDownLeft', s1, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Left/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Left/');
		s1_current = s1;
	 }
}

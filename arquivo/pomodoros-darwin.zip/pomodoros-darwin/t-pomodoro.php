<?php
/*Template Name: Pomodoro*/
?>
<?php get_header() ?>


<?php
//get the language file
   if(qtrans_getLanguage() == "en")
	$filelang="en.js";
   else if(qtrans_getLanguage() == "pt")
	$filelang="pt-br.js";

?>
<!--MooTools-->
<script src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/mootools-1.2.js" type="text/javascript"></script>
<!--jQuery-->
<script src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/jquery-1.6.1.min.js" type="text/javascript"></script>
<!--Sound System-->
<script src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/soundmanager2-nodebug-jsmin.js" type="text/javascript"></script>
<!--Pomodoros-->
<script src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/languages/<?php echo $filelang ?>" type="text/javascript"></script>
<script src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/pomodoro-teste.js" type="text/javascript"></script>
<!--Tips-->
<script src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/tips.js" type="text/javascript"></script>

	<!--Template-->
	<?php get_sidebar() ?>
	<?php locate_template( array( 's-pomodoros.php' ), true ) ?>
	<div id="content" class="content_pomodoro">
		<div class="pomodoro-painel">
			<? /*php if(is_user_logged_in()) {?*/ ?>
			<?php /*
			<h2 class="posttitle"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php _e( 'Permanent Link to', 'buddypress' ) ?> <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
			*/?>
			
			<div id="pomodoro-relogio">							
			<form>
			<!--input type="button" value="Functions!" onclick="savepomo()" id="botao_salvar" /-->
			<input type="button" value="Pomodoro!" onclick="action_button()" id="action_button_id" />
			<!-- input type="button" value="cancelar!" onclick="cancelar()" id="botao_cancelar" /!-->
			</form>

			<div id="relogio">

				<div id="back">
				 <div id="upperHalfBack">
				 		<img src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/spacer.png" />
					<img id="minutesUpLeftBack" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Up/Left/0.png" class="asd" /><img id="minutesUpRightBack" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Up/Right/0.png"/>
					<img id="secondsUpLeftBack" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Up/Left/0.png" /><img id="secondsUpRightBack" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Up/Right/0.png"/>
				 </div>
				 <div id="lowerHalfBack">
				 		<img src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/spacer.png" />
				       <img id="minutesDownLeftBack" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Down/Left/0.png" /><img id="minutesDownRightBack" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Down/Right/0.png" />
				       <img id="secondsDownLeftBack" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Down/Left/0.png" /><img id="secondsDownRightBack" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Down/Right/0.png" />
				 </div>
				</div>
			    
			    
			    <div id="front">
				 <div id="upperHalf">
				 		<img src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/spacer.png" />
					<img id="minutesUpLeft" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Up/Left/0.png" /><img id="minutesUpRight" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Up/Right/0.png"/>
					<img id="secondsUpLeft" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Up/Left/0.png" /><img id="secondsUpRight" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Up/Right/0.png"/>
				 </div>
				 <div id="lowerHalf">
				 		<img src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/spacer.png" />
				       <img id="minutesDownLeft" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Down/Left/0.png" /><img id="minutesDownRight" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Down/Right/0.png" />
				       <img id="secondsDownLeft" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Down/Left/0.png" /><img id="secondsDownRight" src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/Double/Down/Right/0.png" />
				 </div>
				</div>
			</div><!--fecha relogio-->
			<ul id="pomolist">
				<li class="pomoindi" id="pomoindi1">&nbsp;</li>							
				<li class="pomoindi" id="pomoindi2">&nbsp;</li>
				<li class="pomoindi" id="pomoindi3">&nbsp;</li>
				<li class="pomoindi" id="pomoindi4">&nbsp;</li>
			</ul>
			</div><!--fecha pomodoros painel-->
			<br />&nbsp;
			<div id="div_status">Status: clique em Pomodoro para ativar!</div>
			<br />&nbsp;
			
			<form>
				<label><?php _e("<!--:en-->Write down the task you are working on:<!--:--><!--:pt-->Escreva a tarefa que vai realizar:<!--:-->") ?></label><br />
				<input type="text" size="34" id="description_box"></input>
			</form>
			<ul id="points_completed">
			<?php
			$arDates = get_user_meta(get_current_user_id(), "point_date", $single = false);
			$arDescr = get_user_meta(get_current_user_id(), "point_desc", $single = false);
			//$todays_date = date("Y-m-d H:i:s");
			//$today = strtotime($todays_date);
			
			$i=0;
			foreach ($arDates as $key) {
				echo "<li>".$arDates[$i]." -> ".$arDescr[$i]."</li>";
				//$date_stored = strtotime($arDates[$i]);
				//echo "<li>".$date_stored." -> ".$today."</li>";
				
				$i++;
			}
			?>
			</ul>
			<?php /*
			<p>O painel acima permite você controlar seus pomodoros</p>
			<p class="date"><?php the_time() ?> <em><?php _e( 'in', 'buddypress' ) ?> <?php the_category(', ') ?> <?php printf( __( 'by %s', 'buddypress' ), bp_core_get_userlink( $post->post_author ) ) ?></em></p>

			<div class="entry">
				<?php the_content( __( 'Read the rest of this entry &rarr;', 'buddypress' ) ); ?>
			</div>

			<p class="postmetadata"><span class="tags"><?php the_tags( __( 'Tags: ', 'buddypress' ), ', ', '<br />'); ?></span> <span class="comments"><?php comments_popup_link( __( 'No Comments &#187;', 'buddypress' ), __( '1 Comment &#187;', 'buddypress' ), __( '% Comments &#187;', 'buddypress' ) ); ?></span></p>
			*/?>
			<?php /*} else {?>
			<h2><?php _e("<!--:en-->Pomodoros Dashboard<!--:--><!--:pt-->Painel dos Pomodoros<!--:-->") ?></h2>
			<p><?php _e("<!--:en-->You must log in or create a free account to see the content<!--:--><!--:pt-->Conteúdo exclusivo, crie uma conta gratuitamente e tenha acesso<!--:-->") ?></p>
			<?php } */?>
		</div>		
	</div><!-- #content -->

	<?php /*locate_template( array( 'sidebar.php' ), true ) */?>
	
	
	<?php /*locate_template( array( 'sidebar.php' ), true ) */?>
<?php get_footer() ?>


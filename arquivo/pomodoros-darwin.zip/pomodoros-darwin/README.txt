Darwin is part of BuddyPress BuddyPack (B2), a GPL freebie. 

For official news bits, tweets and other flashy things, please visit http://www.AvenueB2.com

- Michael Kuhlmann
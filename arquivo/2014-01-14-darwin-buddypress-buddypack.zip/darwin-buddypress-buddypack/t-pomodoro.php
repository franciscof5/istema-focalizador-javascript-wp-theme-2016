<?php
/*Template Name: Pomodoro Painel*/

/*Language files are loaded on header*/
?>
<?php get_header() ?>

<!--MooTools-->
<script src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/mootools-1.2.js" type="text/javascript"></script>
<!--jQuery-->
<script src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/jquery-1.6.1.min.js" type="text/javascript"></script>
<!--Sound System-->
<script src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/soundmanager2-nodebug-jsmin.js" type="text/javascript"></script>
<!--Tips-->
<script src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/tips.js" type="text/javascript"></script>
<!--Pomodoros-->
<?php if ( current_user_can( 'manage_options' ) ) { ?>
	<script src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/pomodoro-functions-admin.js" type="text/javascript"></script>
<?php } else { ?>
	<script src="<?php bloginfo('stylesheet_directory'); ?>/pomodoro/pomodoro-functions.js" type="text/javascript"></script>
<?php } ?>

	<?php if (is_user_logged_in()) { ?>
		<!--Template-->
		<?php get_sidebar(); ?>
	
		<?php locate_template( array( 's-pomodoros.php' ), true ); ?>
		<div class="content_pomodoro">
			<?php locate_template( array( 'pomodoros-painel.php' ), true ); ?>
		</div><!-- #content -->
	<? } else { ?>
		<div id="content_inicio">
			<div class="circulo" id="">
				<h3>Origem</h3>
				<img />
				<p>Criada por Francesco Cerello na década de 80, para estudar para provas, usava um relógio que marca tempo para assar pizza.</p>
			</div>
			<div class="circulo" id="">
				<h3>Como funciona</h3>
				<img />
				<p>São 25 minutos focando na tarefa e 5 minutos de descanso, formando um ciclo. Após 4 ciclos tem um intervalo de 20 minutos.</p>
			</div>
			<div class="circulo" id="">
				<h3>Benefícios</h3>
				<img />
				<ul>
					<li>Aumenta o foco e produtividade.</li>
					<li>Diminui ansiedade.</li>
					<li>Mais controle sobre demandas.</li>
				</ul>
			</div>
			<div class="circulo" id="">
				<h3>Calendário</h3>
				<img />
				<p>Com o nosso sistema você tem um calendário dinâmico e pode coferir o que estudou/trabalhou em cada dia.</p>
			</div>
			<div class="circulo" id="">
				<h3>Prêmios</h3>
				<img />
				<p>Estude, trabalhe a ainda ganhe prêmios, como se fosse um jogo. Concorra a livros e eletrônicos.</p>
			</div>
			<div class="circulo" id="">
				<h3>Projetos</h3>
				<img />
				<p>Tenha controle sobre seus projetos e perceba quanto tempo usa em cada, com nosso exclusivo gerador de relatório.</p>
			</div>
			<div class="circulo" id="">
				<h3>Rede social</h3>
				<img />
				<p>Estudar sozinho nunca mais! Adicione seus colegas de trabalho, escola e faculdade, compartilhe e comente suas tarefas.</p>
			</div>
			<div class="circulo" id="">
				<h3>Brasil</h3>
				<img />
				<p>Tecnologia nacional, desenvolvida por uma empresa 100% brasileira. Estamos localizados no centro de São Paulo.</p>
			</div>
			<?php
				/*
				$my_id = 3096;
				
				$post_id = get_post($my_id); 
				$title = $post_id->post_title;
				$content = $post_id->post_content;
				_e("<h1>".$title."</h1>");
				_e($content);
				echo '<h2>Teste</h2>';
				*/
			?> 
			<?php  ?>
		</div><!-- #content -->
	<? } ?>
	<?php /*locate_template( array( 'sidebar.php' ), true ) */?>
	
	
	<?php /*locate_template( array( 'sidebar.php' ), true ) */?>
<?php get_footer() ?>
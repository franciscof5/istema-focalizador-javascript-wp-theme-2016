//Language vars
var textPomodoro = "Pomodoro!";
var textRest = "Rest!";
var textBigRest = "Big rest!";
var textInterrupt = "Interrupt!";
// JavaScript Document


//initial time
//var h_current = -1;
var m1_current = 2;
var m2_current = 5;
var s1_current = 0;
var s2_current= 0;
/*f5*/
var pomodoro_actual = 1;
//flip_pomodoro("pomoindi2");

//var interval_clock;


//logo abaixo eh declarada var minutesRemaing=25;	

function flip (upperId, lowerId, changeNumber, pathUpper, pathLower){
	var upperBackId = upperId+"Back";
	$(upperId).src = $(upperBackId).src;
	$(upperId).setStyle("height", "64px");
	$(upperId).setStyle("visibility", "visible");
	$(upperBackId).src = pathUpper+parseInt(changeNumber)+".png";
	
	$(lowerId).src = pathLower+parseInt(changeNumber)+".png";
	$(lowerId).setStyle("height", "0px");
	$(lowerId).setStyle("visibility", "visible");
	
	var flipUpper = new Fx.Tween(upperId, {duration: 200, transition: Fx.Transitions.Sine.easeInOut});
	flipUpper.addEvents({
		'complete': function(){
			var flipLower = new Fx.Tween(lowerId, {duration: 200, transition: Fx.Transitions.Sine.easeInOut});
				flipLower.addEvents({
					'complete': function(){	
						lowerBackId = lowerId+"Back";
						$(lowerBackId).src = $(lowerId).src;
						$(lowerId).setStyle("visibility", "hidden");
						$(upperId).setStyle("visibility", "hidden");
					}				});					
				flipLower.start('height', 64);
				
		}
						});
	flipUpper.start('height', 0);
	
	
}//flip
function flip_pomodoro (pomo) {
	//alert(pomo);
	//var flipPomo = new Fx.Tween($(pomo), {duration: 200, transition: Fx.Transitions.Sine.easeInOut});
	//flipPomo.start();
	var pomo = $(pomo);
	
	pomo.set('morph', {
		duration: 2000
	});
	
	pomo.morph({
		'background-position': '-30px',
		//'border': '2px solid #F00',
		'background-color': '#FFF'
	});
}
	
function retroClock(){
/*
// get new time
 now = new Date();
// h = now.getHours();
 m1 = now.getMinutes() / 10;
 m2 = now.getMinutes() % 10;
 s1 = now.getSeconds() / 10;
 s2 = now.getSeconds() % 10;
*/
//function		
// h = now.getHours();

if(secondsRemaing==1500) {
//Inicio
m1 = 2;
m2 = 4;
s1 = 5;
s2 = 9;
seconds=10;
minutesRemaing=25;	

} else {
//Outras rodadas
if(((minutesRemaing*60)-secondsRemaing)<60) {
	//Vai aqui se for baixar os segundos
	//alert();
	if(((minutesRemaing*60)-secondsRemaing)<seconds)
	s2=seconds-((minutesRemaing*60)-secondsRemaing);
	else {
		s1--;
		seconds+=10;
	}
} else {
minutesRemaing--;
m2--;
seconds=10;
s1=5;
}
//Vai aqui se for baixar os minutos
if(secondsRemaing==1) {
cancelar()
} else if(secondsRemaing==10*60) {
m1=0;
m2=9;
} else if(secondsRemaing==20*60) {
m1=1;
m2=9;
}

}
secondsRemaing--;

if( m2 != m2_current){
	flip('minutesUpRight', 'minutesDownRight', m2, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Right/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Right/');
	m2_current = m2;
	
	flip('minutesUpLeft', 'minutesDownLeft', m1, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Left/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Left/');
	m1_current = m1;
}

 if (s2 != s2_current){
	flip('secondsUpRight', 'secondsDownRight', s2, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Right/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Right/');
	s2_current = s2;
	
	flip('secondsUpLeft', 'secondsDownLeft', s1, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Left/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Left/');
	s1_current = s1;
}	
}
function ativar() {
	secondsRemaing=1500;
	interval_clock = setInterval('retroClock()', 1000);
	flip_pomodoro(1);
}
function cancelar() {
	window.clearInterval(interval_clock);
	interval_clock="";
	set_to_25();
	//flip_pomodoro("pomoindi2");
}
function set_to_25() {
	m1=2;m2=4;s1=5;s2=9;
	flip('minutesUpRight', 'minutesDownRight', 5, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Right/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Right/');
	flip('minutesUpLeft', 'minutesDownLeft', 2, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Left/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Left/');
	flip('secondsUpRight', 'secondsDownRight', 0, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Right/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Right/');
	flip('secondsUpLeft', 'secondsDownLeft', 0, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Up/Left/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/f5sites/Double/Down/Left/');
}
function set_to_0() {
	flip('minutesUpRight', 'minutesDownRight', 0, 'Double/Up/Right/', 'Double/Down/Right/');
	flip('minutesUpLeft', 'minutesDownLeft', 0, 'Double/Up/Left/', 'Double/Down/Left/');
	flip('secondsUpRight', 'secondsDownRight', 0, 'Double/Up/Right/', 'Double/Down/Right/');
	flip('secondsUpLeft', 'secondsDownLeft', 0, 'Double/Up/Left/', 'Double/Down/Left/');
}

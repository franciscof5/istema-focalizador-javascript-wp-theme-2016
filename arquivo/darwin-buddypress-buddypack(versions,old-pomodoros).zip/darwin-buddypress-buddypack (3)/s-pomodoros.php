<div class="sidebar" id="sidebar_pomodoro">
	<div class="padder">

	<h3><script>document.write(txt_tips_heading)</script></h3>
	<p><script>document.write(txt_tips_description)</script></p>
	<input type="button" onclick="proxima_dica()" value="" id="botao_dicas">
	<ul id="dicas">
		<li id="dica_1"><script>document.write(txt_tips_1)</script></li>
		<li id="dica_2"><script>document.write(txt_tips_2)</script></li>
		<li id="dica_3"><script>document.write(txt_tips_3)</script></li>
		<li id="dica_4"><script>document.write(txt_tips_4)</script></li>
		<li id="dica_5"><script>document.write(txt_tips_5)</script></li>
		<li id="dica_6"><script>document.write(txt_tips_6)</script></li>
		<li id="dica_7"><script>document.write(txt_tips_7)</script></li>
		<li id="dica_8"><script>document.write(txt_tips_8)</script></li>
		<li id="dica_9"><script>document.write(txt_tips_9)</script></li>
		<li id="dica_10"><script>document.write(txt_tips_last)</script></li>
	</ul>
	
	</div>
</div>
<?php
/*Template Name: Pomo - Planejador (goals)*/
?>
<?php get_header() ?>

<div class="content_nosidebar">
     $("#e20").select2({
    tags:["red", "green", "blue"],
    tokenSeparators: [",", " "]});
    })
</div><!-- #content -->
	
<?php get_footer() ?>
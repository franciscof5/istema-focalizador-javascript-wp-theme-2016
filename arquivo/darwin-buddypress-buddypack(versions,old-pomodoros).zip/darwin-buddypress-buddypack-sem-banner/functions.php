<?php

function save_progress () {
	//http://codex.wordpress.org/Function_Reference/get_current_user_id
	//http://codex.wordpress.org/Function_Reference/get_currentuserinfo
	
	//global $wpdb; // this is how you get access to the database
	//$foi = $wpdb->insert( "wp_usermeta", array( 'umeta_id' => 'NULL', 'user_id' => 2, 'meta_key' => "pomodoro_completed", 'meta_value' => "delete teste" ));	

	$mysqldate = date('Y-m-d H:i:s', $phpdate);
	$phpdate = strtotime($mysqldate);
	$foi1 = add_user_meta(get_current_user_id(), "point_date", date("Y-m-d H:i:s"));
	$foi2 = add_user_meta(get_current_user_id(), "point_desc", $_POST['descri']);
	
	if($foi1 and $foi2) {
		echo "1 Progresso salvado com sucesso!";
	} else {
		echo "0 Problema ao salvar, você está conectado na internet?";
	}
	
	die(); 
	//$whatever = $_POST['whatever'];
	//$whatever += 10;
	//echo $whatever;
	
	/*$save_query = $wpdb->insert( $wpdb->usermeta, array(
            'option_name',
            'new_option_key',
            'option_value' => 'New Option Value',
            'autoload' => 'yes' )
        );*/
	//$myrows = $wpdb->get_row("SELECT user_nicename FROM wp_users WHERE id=2");
        //$mylink = $wpdb->get_row("SELECT * FROM $wpdb->links WHERE link_id = 8");
	//$mylink = $wpdb->get_row("SELECT * FROM wp_links WHERE link_id = 8");
	
	/*
	FUNCIONA DESCOMENTA ACIMA

	$mylink = $wpdb->query("SELECT * FROM wp_users WHERE ID=20 ");
	//$mylink = $wpdb->get_row("SELECT * FROM wp_users");
	echo $mylink; // prints "10"
	//echo $mylink['link_id']; // prints "10"
	//echo " -> fechado";
	*/
	
	// this is required to return a proper result	
	//$date = date('Y-m-d H:i:s'); 

	/*$save_query = $wpdb->insert( $wpdb->usermeta, array(
		    'option_name',
		    'new_option_key',
		    'option_value' => 'New Option Value',
		    'autoload' => 'yes' )
		    );
	
	if($save_query)
	echo "Pomodoro salvado com sucesso";
	else
	echo "Erro ao salvar pomodoro! Você está conectado a internet?";*/
	//echo "<script>alert('Pomodoro salvado com sucesso')</script>";
	//echo "Pomodoro salvado com sucesso";
	//}

	//add_action('wp_ajax_my_action', 'my_action_callback');
	//	echo  "php ready";
}
add_action('wp_ajax_save_progress', 'save_progress');
add_action('wp_ajax_nopriv_save_progress', 'save_progress');
/**/

	register_sidebar( array(
		'name' => __( 'pomodoros'),
		'id' => 'pomodoros',
		'description' => __( 'Sidebar pomodoros'),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	register_sidebar( array(
		'name' => __( 'geral'),
		'id' => 'geral',
		'description' => __( 'Sidebar geral'),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

/**/
function buddypack_add_custom_header_support() {
	define( 'HEADER_TEXTCOLOR', 'FFFFFF' );
	define( 'HEADER_IMAGE', '%s/_inc/images/darwin-sample-x.gif' ); // %s is theme dir uri
	define( 'HEADER_IMAGE_WIDTH', 1250 );
	define( 'HEADER_IMAGE_HEIGHT', 125 );

	function buddypack_header_style() { ?>
		<style type="text/css">
			#header { background-image: url(<?php header_image() ?>); }
			<?php if ( 'blank' == get_header_textcolor() ) { ?>
			#header h1, #header #desc { display: none; }
			<?php } else { ?>
			#header h1 a, #desc { color:#<?php header_textcolor() ?>; }
			<?php } ?>
		</style>
	<?php
	}

	function buddypack_admin_header_style() { ?>
		<style type="text/css">
			#headimg {
				position: relative;
				color: #fff;
				background: url(<?php header_image() ?>);
				-moz-border-radius-bottomleft: 6px;
				-webkit-border-bottom-left-radius: 6px;
				-moz-border-radius-bottomright: 6px;
				-webkit-border-bottom-right-radius: 6px;
				margin-bottom: 20px;
				height: 100px;
				padding-top: 25px;
			}

			#headimg h1{
				position: absolute;
				bottom: 15px;
				left: 15px;
				width: 44%;
				margin: 0;
				font-family: Arial, Tahoma, sans-serif;
			}
			#headimg h1 a{
				color:#<?php header_textcolor() ?>;
				text-decoration: none;
				border-bottom: none;
			}
			#headimg #desc{

				color:#<?php header_textcolor() ?>;
				font-size:1em;
				margin-top:-0.5em;
			}

			#desc {
				display: none;
			}

			<?php if ( 'blank' == get_header_textcolor() ) { ?>
			#headimg h1, #headimg #desc {
				display: none;
			}
			#headimg h1 a, #headimg #desc {
				color:#<?php echo HEADER_TEXTCOLOR ?>;
			}
			<?php } ?>
		</style>
	<?php
	}
	add_custom_image_header( 'buddypack_header_style', 'buddypack_admin_header_style' );
}

?>

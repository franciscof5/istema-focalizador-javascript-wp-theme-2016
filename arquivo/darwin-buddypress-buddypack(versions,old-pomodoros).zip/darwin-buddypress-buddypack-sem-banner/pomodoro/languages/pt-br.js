//Language vars
var textPomodoro = "Pomodoro!";
var textRest = "Descansar!";
var textBigRest = "Grande descanso!";
var textInterrupt = "Interromper!";
<?php
//TABLE wp_user
//first_access
//pomodoros_this_month++
//sessions_this_month
//meta_pomodoros
//last_pomodoro_descricao

//TABLE pomodoros
//pomodoroID
//userID
//time
//descricao
//$wpdb->insert( "wp_usermeta", "pomodoro", time() ); 
/*echo "salvando".$_GET["pomo"];
if(isset($_GET["n"])){
    $t=leconteudo(intval($_GET["n"]));
    echo(urlencode($t));
}*/
/*echo "sarvado";*/
$date = date('Y-m-d H:i:s'); 

$save_query = $wpdb->insert( $wpdb->usermeta, array(
            'option_name',
            'new_option_key',
            'option_value' => 'New Option Value',
            'autoload' => 'yes' )
            );
/*
if($save_query)
echo "Pomodoro salvado com sucesso";
else
echo "Erro ao salvar pomodoro! Você está conectado a internet?";
*/

echo  $_GET['userID'];
?>

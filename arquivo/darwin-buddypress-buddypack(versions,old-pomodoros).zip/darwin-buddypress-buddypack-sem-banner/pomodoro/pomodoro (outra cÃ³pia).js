// JavaScript Document
//Language vars are in files on the 'language' folder
/*
var textPomodoro = "Pomodoro!";
var textRest = "Descansar!";
var textBigRest = "Grande descanso!";
var textInterrupt = "Interromper!";
*/

//Configurantion vars, will be user set
var pomodoros_to_big_rest=4;

var pomodoroTime = 1500;
var restTime = 300;
var bigRestTime = 1800;
var intervalMiliseconds = 1000;

//Dynamic clock var
var is_interrupt_button;
var m1;
var m2;
var m3;
var m4;
var m1_current = 2;
var m2_current = 5;
var s1_current = 0;
var s2_current= 0;

//Pomodoro session control vars
var pomodoro_actual = 1;
var is_pomodoro = true;
var secondsRemaing = pomodoroTime;


//Ajax
function savepomo () {
	var avisos=document.getElementById("avisos");
	avisos.innerHTML='Status: salvando pomodoro...'
	
	/*$.ajax({
	    type: 'POST',
	    url: '/wp-admin/admin-ajax.php',
	    data: 'action=salvarPomodoro',
	    success: function( response ){
		    alert('sucesso');
		    }
	});
	die();*/
	var description=document.getElementById("description_box");
	//alert(description.value);
	var data = {
		action: 'salvarPomodoro',
		descri: description.value
	};

	// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
	jQuery.post(ajaxurl, data, function(response) {
		avisos.innerHTML='Status: ' + response;
	});
}

//Sound configuration
soundManager.url = 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/pomodoro/soundmanager2.swf';
soundManager.onready(function() {
	// Ready to use; soundManager.createSound() etc. can now be called.
	active_sound = soundManager.createSound({id: 'mySound2',url: 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/pomodoro/sounds/crank-2.mp3',});
	pomodoro_completed_sound = soundManager.createSound({id:'mySound3',url: 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/pomodoro/sounds/telephone-ring-1.mp3',});
});
soundManager.onerror = function() {
	alert('Erro ao reproduzir o som: Alerta visual ativado! Clique em ok para continuar!');
}

function ativar(time) {
	//convertSeconds(secondsRemaing)
	//var avisos=document.getElementById("avisos")
	
	if(is_interrupt_button) {
		//The pomodoro was interrupted after completes
		pomodoro_completed_sound.play();
		//
		interrupt();
		//avisos.innerHTML='Status: pomodoro cancelado!'
	} else {
		//Pomodoro or rest buttons, ready to be clicked
		active_sound.play();
		//
		if(pomodoro_actual==1) {
			flip_pomodoro_back();
		}
		//Chage button to "interrupt"		
		is_interrupt_button=true;
		flip_botao(textInterrupt, "#0F0F0F");
		//avisos.innerHTML='Status: pomodoro ativado!'
		//Start the interval
		interval_clock = setInterval('retroClock()', intervalMiliseconds);
	}
}

function complete() {
	is_interrupt_button = false;
	pomodoro_completed_sound.play();
	cancelar();
	if(is_pomodoro) {
		flip_pomodoro("pomoindi"+pomodoro_actual);
		if(pomodoro_actual==pomodoros_to_big_rest) {
			//big rest	
			pomodoro_actual=1;
			flip_botao(textBigRest, "#0F0");
			secondsRemaing=bigRestTime;
		} else {
			//normal rest
			pomodoro_actual++;
			flip_botao(textRest, "#42C93E");
			secondsRemaing=restTime;
		}
		is_pomodoro = false;
	} else {
		flip_botao(textPomodoro, "#BC1800");
		secondsRemaing=pomodoroTime;
		is_pomodoro=true;
	}
}
function interrupt() {
	cancelar();
	convertSeconds(0);
	flip_number();
	flip_botao(textPomodoro, "#700000");
	secondsRemaing=0;
	secondsRemaing = pomodoroTime;
	is_interrupt_button=false;
	if(!is_pomodoro)is_pomodoro=true;
}
function convertSeconds(secs) {
	minutes=secs/60;
	if(minutes>10) {
		someValueString = '' + minutes;
		someValueParts = someValueString.split('');
		m1 = parseFloat(someValueParts[0]);
		m2 = parseFloat(someValueParts[1]);
	} else {
		m1 = parseFloat(0);
		m2 = parseFloat(minutes);
	}
	//seconds%=secs/60;
	if(secs%60!=0) {
		seconds=secs%60;
		otherValueString = '' + seconds;
		otherValueParts = otherValueString.split('');
		if(seconds>10) {
			s1 = parseFloat(otherValueParts[0]);
			s2 = parseFloat(otherValueParts[1]);
		} else {
			s1=0;
			s2=parseFloat(otherValueParts[0]);
		}
	} else {
		s1=0;
		s2=0;
	}
	//alert(m1+""+m2+":"+s1+""+s2);
}
function cancelar() {
	window.clearInterval(interval_clock);
	interval_clock="";
}
function retroClock(){
	secondsRemaing--;
	//alert(secondsRemaing);
	convertSeconds(secondsRemaing);
	flip_number();
	if(secondsRemaing==0) {
		complete();
	}
}	
//flip
function flip_botao (valueset, colorset) {
	//alert($("#botao_ativar").val());	
	//$("#botao_ativar").val(valueset);	
	//$("#botao_ativar").css("background-color", colorset);
	var botao = $("botao_ativar");
	
	botao.value=valueset;
	
	botao.set('morph', {
		duration: 2000
	});
	
	botao.morph({
		//'border': '2px solid #F00',
		'background-color': colorset
	});
}
function flip_pomodoro (pomo) {
	var pomo = $(pomo);
	
	pomo.set('morph', {duration: 2000});
	
	pomo.morph({'background-position': '-30px','background-color': '#FFF'});
}
function flip_pomodoro_back () {
	var pomo1 = $("pomoindi1");
	var pomo2 = $("pomoindi2");
	var pomo3 = $("pomoindi3");
	var pomo4 = $("pomoindi4");
	
	pomo1.set('morph', {duration: 4000});
	pomo2.set('morph', {duration: 2000});
	pomo3.set('morph', {duration: 3000});
	pomo4.set('morph', {duration: 1200});
	
	pomo1.morph({'background-position': '0px','background-color': '#EEEEEE'});
	pomo2.morph({'background-position': '0px','background-color': '#EEEEEE'});
	pomo3.morph({'background-position': '0px','background-color': '#EEEEEE'});
	pomo4.morph({'background-position': '0px','background-color': '#EEEEEE'});
}
function flip_number() {
	if( m2 != m2_current){
		flip('minutesUpRight', 'minutesDownRight', m2, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/pomodoro/Double/Up/Right/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/pomodoro/Double/Down/Right/');
		m2_current = m2;
		
		flip('minutesUpLeft', 'minutesDownLeft', m1, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/pomodoro/Double/Up/Left/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/pomodoro/Double/Down/Left/');
		m1_current = m1;
	}
	
	 if (s2 != s2_current){
		flip('secondsUpRight', 'secondsDownRight', s2, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/pomodoro/Double/Up/Right/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/pomodoro/Double/Down/Right/');
		s2_current = s2;
		
		flip('secondsUpLeft', 'secondsDownLeft', s1, 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/pomodoro/Double/Up/Left/', 'http://pomodoros.com.br/wp-content/themes/darwin-buddypress-buddypack/pomodoro/Double/Down/Left/');
		s1_current = s1;
	 }
}

function flip (upperId, lowerId, changeNumber, pathUpper, pathLower){
	var upperBackId = upperId+"Back";
	
	$(upperId).src = $(upperBackId).src;
	$(upperId).setStyle("height", "64px");
	$(upperId).setStyle("visibility", "visible");
	$(upperBackId).src = pathUpper+parseInt(changeNumber)+".png";
	
	$(lowerId).src = pathLower+parseInt(changeNumber)+".png";
	$(lowerId).setStyle("height", "0px");
	$(lowerId).setStyle("visibility", "visible");
	
	/*
	alert($(upperId).src);
	$(upperId).src = $(upperBackId).src;
	$(upperId).setStyle("height", "64px");
	$(upperId).setStyle("visibility", "visible");
	$(upperBackId).src = pathUpper+parseInt(changeNumber)+".png";
	
	$(lowerId).src = pathLower+parseInt(changeNumber)+".png";
	$(lowerId).setStyle("height", "0px");
	$(lowerId).setStyle("visibility", "visible");
	*/

	var flipUpper = new Fx.Tween(upperId, {duration: 200, transition: Fx.Transitions.Sine.easeInOut});
	flipUpper.addEvents({
		'complete': function(){
			var flipLower = new Fx.Tween(lowerId, {duration: 200, transition: Fx.Transitions.Sine.easeInOut});
				flipLower.addEvents({
					'complete': function(){	
						lowerBackId = lowerId+"Back";
						$(lowerBackId).src = $(lowerId).src;
						$(lowerId).setStyle("visibility", "hidden");
						$(upperId).setStyle("visibility", "hidden");
					}				});					
				flipLower.start('height', 64);
				
		}
	});
	flipUpper.start('height', 0);
}
